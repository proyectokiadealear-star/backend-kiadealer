export enum SedeEnum {
  SURMOTOR = 'SURMOTOR',
  SHYRIS = 'SHYRIS',
  GRANDA_CENTENO = 'GRANDA_CENTENO',
  ALL = 'ALL',
}
